# Het Verhaal van de Straw Hat Pirates

Het verhaal begint in het East Blue-gebied, waar Luffy zijn reis start.  
Tijdens zijn avontuur verzamelt hij een unieke bemanning met elk hun eigen dromen.  
Samen reizen ze over de _Grand Line_ op zoek naar de schat _One Piece_.

Onderweg ontmoeten ze machtige vijanden, wereldregeringen, en andere piratencrews.  
Het verhaal draait om vriendschap, vrijheid en nooit opgeven, ongeacht de obstakels.

Het volgende hoofdstuk van hun reis brengt de Straw Hat Pirates naar nieuwe eilanden, onbekende gevaren en onverwachte bondgenoten.  
Luffy en zijn crew blijven vastberaden om One Piece te vinden, wat er ook gebeurt.
