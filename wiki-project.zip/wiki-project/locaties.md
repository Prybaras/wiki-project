# Belangrijke Locaties

### 🏠 East Blue

Het beginpunt van Luffy’s reis.  
Veel van de oorspronkelijke bemanningsleden komen hier vandaan.

### ⛰️ Grand Line

De gevaarlijkste zee ter wereld — vol met zeemonsters, mysteries en schatten.

### ⚖️ Mariejois

De hoofdstad van de wereldregering en thuis van de _Celestial Dragons_.
