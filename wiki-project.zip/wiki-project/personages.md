# Belangrijkste Personages

### 🏴‍☠️ Monkey D. Luffy

Kapitein van de Straw Hat Pirates.  
Hij at de _Gomu Gomu no Mi_ vrucht, waardoor zijn lichaam rubberachtig werd.  
Luffy is vrolijk, impulsief en vastberaden om Piraatkoning te worden.

### ⚔️ Roronoa Zoro

De zwaardvechter van de crew, bekend om zijn _drie-zwaardenstijl_.  
Zijn doel is de beste zwaardvechter ter wereld te worden.

### 💰 Nami

De navigator van de crew.  
Ze is slim, houdt van kaarten en — vooral — van geld.  
Haar droom is om een complete kaart van de wereld te maken.
