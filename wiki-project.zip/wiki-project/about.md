# Over mij

Hallo! Mijn naam is Guled, en ik ben een grote fan van _One Piece_.  
Ik volg de anime al jaren en bewonder de boodschap van vrijheid en vriendschap.  
Met deze Wiki wil ik de wereld van One Piece op een gestructureerde manier delen.
